Contributions and development
=============================

Contributions to the TraX protocol and library are welcome, the preferred way to do it is by submitting issues or pull requests on `GitHub <https://github.com/votchallenge/trax>`_.
