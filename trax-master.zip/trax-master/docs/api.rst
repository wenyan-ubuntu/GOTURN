API documentation
=================

The TraX API documentation describes technical details of TraX library and bindings to other languages.

.. toctree::
   :maxdepth: 2

   api_c
   api_cpp
   api_python
   api_matlab
   api_client
   api_opencv
