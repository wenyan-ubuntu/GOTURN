# FasterRCNN-Encapsulation-Cplusplus
Encapsulation C++ version of FasterRCNN

Here is C++ Implementation of FasterRCNN Interface. As you can see, there are two folders and you can compile the self-defined cpp files
with caffe, or compile your files as a dynamic lib. 
How to compile it ? I have written the CMakeList.txt that can help you to comiple on 
your own environment. What you need to do is only change some necessary paths. All the code has been tested and the test results are also
included. 
Wish it can help you~~~

####If you find it helpful to you, please give me a star :) Thank you ~~~
