#include "regressor_base.h"

RegressorBase::RegressorBase()
{
}
