% Code to compute Fscore for tracking output (Please look at the example provided)  
% Publication: Visual Tracking: an Experimental Survey
% Arnold W. M. Smeulders, Dung M. Chu, Rita Cucchiara, Simone Calderara, Afshin Dehghan and Mubarak Shah
% In Proceeding of IEEE Transaction on Pattern Analysis and Machine Intelligence (PAMI'2013)


% Example:
Fscore = quantitativeEvaluationFScore_poly('01-Light_video00001.txt','01-Light_video00001.ann',0.5);