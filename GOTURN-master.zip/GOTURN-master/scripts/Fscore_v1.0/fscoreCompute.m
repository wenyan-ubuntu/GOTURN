function fscore = fscoreCompute(P,R)
    fscore = (2*P*R)/(P+R);
end