Tracker integration examples
============================

This folder contains several examples of tracker integration for C/C++, Matlab, and Python trackers. Helpers for all languages are provided so that integration is as easy as adding a few lines of code to your tracker source code. For C/C++ three example trackers are provided in the `native` directory, for Matlab an example tracker is in the `matlab` directory, and for Python in the `python` directory. More information can be found in the [documentation](index.md).

